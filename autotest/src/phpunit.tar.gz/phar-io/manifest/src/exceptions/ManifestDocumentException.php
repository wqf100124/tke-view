<?php

namespace PharIo\Manifest;

class ManifestDocumentException extends \RuntimeException implements Exception {
}
